# godot-movement
Little movement prototyping in the Godot engine.

Icon moves around a 2D plane with non-collidable falling blocks to motivate movement fluidity and responsiveness testing.
